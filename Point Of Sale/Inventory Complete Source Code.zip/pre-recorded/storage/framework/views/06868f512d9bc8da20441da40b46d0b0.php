<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('components.dashboard.summary', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.sidenav-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rabbil/Documents/GitHub/Laravel-Batch/Point Of Sale/pre-recorded/resources/views/pages/dashboard/dashboard-page.blade.php ENDPATH**/ ?>