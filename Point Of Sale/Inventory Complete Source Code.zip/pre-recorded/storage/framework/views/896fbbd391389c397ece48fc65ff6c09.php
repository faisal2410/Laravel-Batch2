<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('components.dashboard.profile-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.sidenav-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rabbil/Documents/GitHub/Laravel-Batch/Point Of Sale/pre-recorded/resources/views/pages/dashboard/profile-page.blade.php ENDPATH**/ ?>